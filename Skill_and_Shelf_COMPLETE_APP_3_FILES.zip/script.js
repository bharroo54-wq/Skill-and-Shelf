var skills=[
{name:"Python",category:"Technical & IT",level:"Advanced"},
{name:"JavaScript",category:"Technical & IT",level:"Intermediate"},
{name:"Excel",category:"Data & Analytics",level:"Advanced"},
{name:"Graphic Design",category:"Creative",level:"Intermediate"},
{name:"Public Speaking",category:"Communication",level:"Advanced"},
{name:"Leadership",category:"People & Social",level:"Intermediate"},
{name:"Problem Solving",category:"Thinking Skills",level:"Advanced"},
{name:"Video Editing",category:"Creative",level:"Advanced"}
];

var books=[
{title:"Engineering Mathematics",author:"B.Tech Mathematics",action:"sell",price:350},
{title:"Python Programming",author:"Programming Fundamentals",action:"exchange",price:0},
{title:"Operating Systems",author:"Computer Science",action:"donate",price:0},
{title:"Business Communication",author:"Communication Skills",action:"sell",price:200},
{title:"Data Structures & Algorithms",author:"Computer Science",action:"sell",price:300},
{title:"English Literature",author:"BA English",action:"exchange",price:0}
];

var currentBookFilter="all";

function $(id){return document.getElementById(id);}

function renderSkills(){
 var grid=$("skillGrid"); if(!grid)return;
 grid.innerHTML="";
 skills.forEach(function(s){
  var card=document.createElement("div"); card.className="skill";
  var b=document.createElement("b"); b.textContent=s.name;
  var l=document.createElement("span"); l.className="level"; l.textContent=s.level;
  var small=document.createElement("small"); small.textContent=s.category;
  card.appendChild(b);card.appendChild(l);card.appendChild(small);grid.appendChild(card);
 });
}

function renderBooks(){
 var grid=$("bookGrid"); if(!grid)return;
 var query=($("bookSearch").value||"").toLowerCase();
 grid.innerHTML="";
 books.filter(function(b){
  var filterOK=currentBookFilter==="all"||b.action===currentBookFilter;
  var text=(b.title+" "+b.author).toLowerCase();
  return filterOK&&text.indexOf(query)!==-1;
 }).forEach(function(b){
  var card=document.createElement("div");card.className="book";
  var cover=document.createElement("div");cover.className="book-cover";cover.textContent="📖";
  var h=document.createElement("h3");h.textContent=b.title;
  var p=document.createElement("p");p.textContent=b.author;
  var tag=document.createElement("span");tag.className="tag";tag.textContent=b.action.toUpperCase();
  var bottom=document.createElement("div");bottom.className="book-bottom";
  var price=document.createElement("strong");
  price.textContent=b.action==="donate"?"FREE":(b.action==="exchange"?"EXCHANGE":"₹"+b.price);
  var button=document.createElement("button");button.textContent=b.action==="sell"?"Buy":(b.action==="exchange"?"Request Exchange":"Request");
  button.onclick=function(){alert("Demo request sent for: "+b.title);};
  bottom.appendChild(price);bottom.appendChild(button);
  card.appendChild(cover);card.appendChild(h);card.appendChild(p);card.appendChild(tag);card.appendChild(bottom);grid.appendChild(card);
 });
}

function showSection(id){
 document.querySelectorAll(".section").forEach(function(s){s.classList.remove("active-section");});
 var section=$(id); if(section){section.classList.add("active-section");section.scrollIntoView({behavior:"smooth"});}
 document.querySelectorAll(".nav-btn").forEach(function(b){b.classList.remove("active");});
 if(id==="skills")document.querySelectorAll(".nav-btn")[1].classList.add("active");
 if(id==="books")document.querySelectorAll(".nav-btn")[2].classList.add("active");
 if(id==="home")document.querySelectorAll(".nav-btn")[0].classList.add("active");
}

function showSearch(){
 var p=$("searchPanel");p.classList.remove("hidden");p.scrollIntoView({behavior:"smooth"});
}
function searchStudent(){
 var id=$("studentId").value.trim().toUpperCase();
 $("searchMessage").textContent=id==="SS26-001"?"Student found ✓":"Try SS26-001 for the demo profile.";
 if(id==="SS26-001")showSection("skills");
}

function openSkillModal(){$("skillModal").classList.remove("hidden");$("skillName").focus();}
function closeSkillModal(){$("skillModal").classList.add("hidden");}
function addSkill(){
 var name=$("skillName").value.trim();
 if(!name){$("skillMessage").textContent="Please enter a skill name.";return;}
 skills.unshift({name:name,category:$("skillCategory").value,level:$("skillLevel").value});
 renderSkills();$("skillMessage").textContent="Skill added successfully ✓";
 $("skillName").value="";
 setTimeout(closeSkillModal,400);
}

function filterBooks(filter,button){
 currentBookFilter=filter;
 document.querySelectorAll(".action-card").forEach(function(b){b.classList.remove("active");});
 button.classList.add("active");renderBooks();
}

function openBookModal(){$("bookModal").classList.remove("hidden");$("bookTitle").focus();}
function closeBookModal(){$("bookModal").classList.add("hidden");}
function addBook(){
 var title=$("bookTitle").value.trim(), author=$("bookAuthor").value.trim();
 if(!title){$("bookMessage").textContent="Please enter a book title.";return;}
 books.unshift({title:title,author:author||"Student listed book",action:$("bookAction").value,price:Number($("bookPrice").value)||0});
 renderBooks();$("bookMessage").textContent="Book listed successfully ✓";
 $("bookTitle").value="";$("bookAuthor").value="";setTimeout(closeBookModal,500);
}

window.showSection=showSection;window.showSearch=showSearch;window.searchStudent=searchStudent;
window.openSkillModal=openSkillModal;window.closeSkillModal=closeSkillModal;window.addSkill=addSkill;
window.filterBooks=filterBooks;window.openBookModal=openBookModal;window.closeBookModal=closeBookModal;window.addBook=addBook;
document.addEventListener("DOMContentLoaded",function(){renderSkills();renderBooks();});